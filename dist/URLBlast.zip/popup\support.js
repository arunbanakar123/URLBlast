// Support Page Logic
const CONFIG = {
  paypalUrl: 'https://www.paypal.com/paypalme/arunbanakar123',
  githubUrl: 'https://github.com/arunbanakar/urlblast'
};

// Load config from storage (optional override)
async function init() {
  try {
    const stored = await chrome.storage.sync.get('urlblast_support');
    if (stored.urlblast_support) {
      if (stored.urlblast_support.paypalUrl) CONFIG.paypalUrl = stored.urlblast_support.paypalUrl;
      if (stored.urlblast_support.githubUrl) CONFIG.githubUrl = stored.urlblast_support.githubUrl;
    }
  } catch(e) { /* standalone page */ }

  // Set PayPal link
  const ppLink = document.getElementById('paypal-link');
  if (ppLink) ppLink.href = CONFIG.paypalUrl;

  // Set GitHub link
  const ghLink = document.getElementById('gh-link');
  if (ghLink) ghLink.href = CONFIG.githubUrl;
}

// Back link
document.getElementById('back-link').addEventListener('click', (e) => {
  e.preventDefault();
  window.close();
});

init();
