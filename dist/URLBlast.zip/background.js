// URLBlast Background Service Worker
// Handles keyboard shortcuts and background tasks

// Offscreen document management
let creating;
async function setupOffscreenDocument(path) {
  if (creating) { await creating; return; }

  // Check if it already exists (if API is available)
  if (chrome.runtime.getContexts) {
    const existing = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [chrome.runtime.getURL(path)]
    });
    if (existing.length > 0) return;
  }

  try {
    creating = chrome.offscreen.createDocument({
      url: path,
      reasons: ['CLIPBOARD'],
      justification: 'Global keyboard shortcuts need clipboard access'
    });
    await creating;
  } catch (err) {
    // If it already exists, Chrome throws an error we can safely ignore
    if (!err.message.includes('Only a single offscreen')) {
      console.error('[URLBlast] Failed to create offscreen doc:', err);
    }
  } finally {
    creating = null;
  }
}

// Helper to show on-page notifications
async function notifyTab(message, status = 'success') {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab || !tab.url || tab.url.startsWith('chrome') || tab.url.startsWith('edge')) return;
    
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (msg, stat) => {
        let snackbar = document.getElementById('urlblast-snackbar');
        if (snackbar) snackbar.remove();

        snackbar = document.createElement('div');
        snackbar.id = 'urlblast-snackbar';
        
        const bgColor = stat === 'error' ? '#f44336' : '#323232';
        
        Object.assign(snackbar.style, {
          position: 'fixed',
          bottom: '32px',
          left: '50%',
          transform: 'translateX(-50%) translateY(100px)',
          backgroundColor: bgColor,
          color: '#ffffff',
          padding: '12px 24px',
          borderRadius: '4px',
          fontSize: '14px',
          fontFamily: 'Roboto, sans-serif',
          zIndex: '2147483647',
          boxShadow: '0 3px 5px -1px rgba(0,0,0,.2), 0 6px 10px 0 rgba(0,0,0,.14), 0 1px 18px 0 rgba(0,0,0,.12)',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          minWidth: '288px',
          maxWidth: '568px',
          transition: 'transform 0.3s cubic-bezier(0, 0, 0.2, 1), opacity 0.3s',
          opacity: '0',
          pointerEvents: 'auto'
        });

        const icon = stat === 'success' ? '✓' : (stat === 'error' ? '✕' : 'ℹ');
        snackbar.innerHTML = `
          <span style="color:${stat === 'success' ? '#4caf50' : '#fff'}; font-weight:bold;">${icon}</span>
          <span style="flex:1;">${msg}</span>
        `;

        document.body.appendChild(snackbar);
        
        // Force reflow
        snackbar.offsetHeight;

        snackbar.style.opacity = '1';
        snackbar.style.transform = 'translateX(-50%) translateY(0)';

        setTimeout(() => {
          snackbar.style.opacity = '0';
          snackbar.style.transform = 'translateX(-50%) translateY(100px)';
          setTimeout(() => snackbar.remove(), 300);
        }, 4000);
      },
      args: [message, status]
    });
  } catch (err) {
    console.warn('[URLBlast] On-page notification failed:', err);
  }
}

chrome.commands.onCommand.addListener(async (command) => {
  // ── Alt+C : Copy all tab URLs (Global) ─────────────────────────────────────
  if (command === 'copy-all-urls') {
    try {
      const tabs = await chrome.tabs.query({ currentWindow: true });
      const urls = tabs.map(tab => tab.url).filter(Boolean).join('\n');

      await setupOffscreenDocument('offscreen.html');
      await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'copy',
        text: urls
      });

      const msg = `✅ ${tabs.length} URLs copied!`;
      await notifyTab(msg, 'success');

      chrome.notifications.create('urlblast-copied', {
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: 'URLBlast',
        message: msg,
        priority: 1
      });
      setTimeout(() => chrome.notifications.clear('urlblast-copied'), 2500);

    } catch (err) {
      console.error('[URLBlast] Error copying URLs:', err);
    }
  }

  // ── Alt+V : Open URLs from clipboard (Global) ──────────────────────────────
  if (command === 'open-urls-clipboard') {
    try {
      await setupOffscreenDocument('offscreen.html');
      const response = await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'paste'
      });

      const text = response?.text || '';
      // Parse URLs from text
      const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"'{}|\\^\[\]`]+/gi;
      let matched = text.match(urlRegex) || [];
      const urls = matched.map(u => u.startsWith('http') ? u : 'https://' + u);

      if (urls.length === 0) {
        chrome.notifications.create('urlblast-error', {
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: 'URLBlast',
          message: '❌ No valid URLs found in clipboard.',
          priority: 1
        });
        return;
      }

      for (let i = 0; i < urls.length; i++) {
        const isLast = i === urls.length - 1;
        await chrome.tabs.create({ url: urls[i], active: isLast });
      }

      const msg = `🚀 Opened ${urls.length} URLs from clipboard!`;
      await notifyTab(msg, 'success');

      chrome.notifications.create('urlblast-opened', {
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: 'URLBlast',
        message: msg,
        priority: 1
      });
      setTimeout(() => chrome.notifications.clear('urlblast-opened'), 2500);

    } catch (err) {
      console.error('[URLBlast] Error opening URLs:', err);
    }
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_VERSION') {
    sendResponse({ version: chrome.runtime.getManifest().version });
  }
  return true;
});

// Clean up old session data periodically
chrome.alarms.create('cleanup', { periodInMinutes: 60 });
chrome.alarms.create('daily-check', { periodInMinutes: 1440 }); // Every 24 hours

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanup') {
    chrome.storage.session.clear();
  }
  if (alarm.name === 'daily-check') {
    checkDonationPrompt();
  }
});

async function checkDonationPrompt() {
  const { urlblast_settings = {} } = await chrome.storage.sync.get('urlblast_settings');
  // Skip if user checked the box
  if (urlblast_settings.disableDonationPrompt) return;

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth(); // 0-11
  const date = now.getDate();
  const day = now.getDay(); // 0 = Sun, 1 = Mon ... 6 = Sat

  // Calculate target date (10th, or next weekday if 10th is weekend)
  let targetDate = 10;
  const tenthDate = new Date(year, month, 10);
  if (tenthDate.getDay() === 6) targetDate = 12; // If Saturday -> move to Monday 12th
  if (tenthDate.getDay() === 0) targetDate = 11; // If Sunday -> move to Monday 11th

  // If today is the target support day
  if (date === targetDate && day >= 1 && day <= 5) {
    const monthKey = `${year}-${month}`;
    const { lastDonationPrompt } = await chrome.storage.sync.get('lastDonationPrompt');
    
    // Make sure we only show it once per month
    if (lastDonationPrompt !== monthKey) {
      await chrome.storage.sync.set({ lastDonationPrompt: monthKey });
      
      // Show OS notification
      const notifId = 'urlblast-donation-' + monthKey;
      chrome.notifications.create(notifId, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title: 'Support URLBlast ☕',
        message: 'URLBlast is free! If it saves you time, consider supporting with a coffee or UPI.',
        buttons: [
          { title: 'Support URLBlast' },
          { title: "Don't show again" }
        ],
        requireInteraction: false
      });

      // Auto-clear notification after 7 seconds
      setTimeout(() => {
        chrome.notifications.clear(notifId);
      }, 7000);
    }
  }
}

// Handle notification button clicks
chrome.notifications.onButtonClicked.addListener(async (notifId, btnIdx) => {
  if (notifId.startsWith('urlblast-donation-')) {
    if (btnIdx === 0) {
      // "Support URLBlast"
      chrome.tabs.create({ url: chrome.runtime.getURL('popup/support.html'), active: true });
      chrome.notifications.clear(notifId);
    } else if (btnIdx === 1) {
      // "Don't show again"
      const { urlblast_settings = {} } = await chrome.storage.sync.get('urlblast_settings');
      urlblast_settings.disableDonationPrompt = true;
      await chrome.storage.sync.set({ urlblast_settings });
      chrome.notifications.clear(notifId);
    }
  }
});

// Check on browser startup / extension load
chrome.runtime.onStartup.addListener(checkDonationPrompt);
chrome.runtime.onInstalled.addListener(checkDonationPrompt);
